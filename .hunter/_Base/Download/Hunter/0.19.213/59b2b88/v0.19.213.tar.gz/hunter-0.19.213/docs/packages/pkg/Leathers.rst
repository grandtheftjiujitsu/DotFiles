.. spelling::

    Leathers

.. index:: warnings ; Leathers

.. _pkg.Leathers:

Leathers
========

-  `Official <https://github.com/ruslo/leathers>`__

.. code-block:: cmake

    hunter_add_package(Leathers)
    find_package(Leathers CONFIG REQUIRED)
    target_link_libraries(... leathers)
