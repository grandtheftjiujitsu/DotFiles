#include <boost/log/core.hpp>

int main() {
}
