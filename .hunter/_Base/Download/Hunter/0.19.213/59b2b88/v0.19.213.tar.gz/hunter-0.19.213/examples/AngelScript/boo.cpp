#include <iostream> // std::cout
#include <AngelScript/angelscript.h>

int main() {
  std::cout << asGetLibraryVersion() << std::endl;
}
