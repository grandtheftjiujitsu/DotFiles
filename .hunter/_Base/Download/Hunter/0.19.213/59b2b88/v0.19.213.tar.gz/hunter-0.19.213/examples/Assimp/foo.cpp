#include <assimp/cimport.h>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

int main() {
}
