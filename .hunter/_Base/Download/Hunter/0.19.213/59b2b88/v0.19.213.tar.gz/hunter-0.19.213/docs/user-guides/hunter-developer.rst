.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Hunter developer
----------------

* reference to modules
* layout guide
