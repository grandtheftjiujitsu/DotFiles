#include <openssl/rsa.h>

int main() {
    auto *rsa = RSA_new();
}
