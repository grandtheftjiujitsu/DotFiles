.. spelling::

    gst

.. index:: media ; gst_plugins_good

.. _pkg.gst_plugins_good:

gst_plugins_good
================

-  `Official <https://gstreamer.freedesktop.org>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/gst_plugins_good/CMakeLists.txt>`__

.. code-block:: cmake

    hunter_add_package(gst_plugins_good)
    # ???
