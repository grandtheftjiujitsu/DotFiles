.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

.. http://www.urbandictionary.com/define.php?term=hunterized :)

Hunterize
=========

The process of teaching CMake project to use packages from Hunter root instead
of default one.

.. seealso::

  * :doc:`New package: CMake with dependencies </creating-new/create/cmake-dependencies>`
