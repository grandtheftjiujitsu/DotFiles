.. spelling::

    pybind
    pybind11
    versa

Scripting
---------

 - :ref:`pkg.Lua` - powerful, efficient, lightweight, embeddable scripting language.
 - :ref:`pkg.pybind11` - a lightweight header-only library that exposes C++ types in Python and vice versa.

