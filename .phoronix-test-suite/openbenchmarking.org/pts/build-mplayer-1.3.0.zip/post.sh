#!/bin/sh

rm -rf MPlayer-1.0rc3/
