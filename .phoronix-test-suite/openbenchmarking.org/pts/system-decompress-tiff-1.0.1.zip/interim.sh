#!/bin/sh

rm mandril.rgba
