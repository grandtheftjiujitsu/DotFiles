#!/bin/sh
rm -f $HOME/.nexuiz/data/screenshots/nexuiz*.tga
