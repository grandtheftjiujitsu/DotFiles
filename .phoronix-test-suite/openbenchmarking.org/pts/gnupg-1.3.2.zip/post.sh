#!/bin/sh

rm -f encryptfile
