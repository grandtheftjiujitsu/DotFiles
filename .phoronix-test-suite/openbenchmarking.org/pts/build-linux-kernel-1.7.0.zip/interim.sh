#!/bin/sh

cd linux-4.9/
make clean
