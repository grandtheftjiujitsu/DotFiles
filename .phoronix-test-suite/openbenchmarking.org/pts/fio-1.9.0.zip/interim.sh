#!/bin/sh

cd fio-2.1.13/
rm -f iometer.0.0
