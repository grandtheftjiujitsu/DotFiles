#!/bin/sh

rm -rf php-5.2.9/
