#!/bin/sh

cd php-5.2.9/
make clean
