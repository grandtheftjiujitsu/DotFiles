#!/bin/sh

rm -rf boost_1_59_0
tar xzf boost_1_59_0.tar.gz
cd boost_1_59_0/libs/interprocess/example
