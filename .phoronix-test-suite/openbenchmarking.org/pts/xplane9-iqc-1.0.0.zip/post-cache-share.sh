#!/bin/sh
rm -f *.png
