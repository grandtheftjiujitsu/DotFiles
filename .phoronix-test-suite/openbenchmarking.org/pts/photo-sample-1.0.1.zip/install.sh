#!/bin/sh

tar -xvf pts-sample-photos-2.tar.bz2
