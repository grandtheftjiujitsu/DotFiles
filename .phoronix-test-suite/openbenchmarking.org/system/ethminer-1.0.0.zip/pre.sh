#!/bin/sh

ethminer --create-dag
