#!/bin/sh

rm -f *.JPG
