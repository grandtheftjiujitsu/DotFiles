#!/bin/sh

rm -f *.JPG
tar -xjvf pts-sample-photos-2.tar.bz2
